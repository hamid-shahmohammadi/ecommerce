<div class="col-md-4 well well-sm">
        

<nav class="nav flex-column">
 
  <a class="nav-link" href="{{'/profile'}}">My Profile</a>
  <a class="nav-link" href="{{'/orders'}}">My Orders</a>
  <a class="nav-link" href="{{'/address'}}">My Address</a>

   <a class="nav-link" href="{{url('/password')}}">Change Password</a>
</nav>
</div>
